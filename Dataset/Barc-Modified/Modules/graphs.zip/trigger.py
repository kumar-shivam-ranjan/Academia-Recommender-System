from abstractsim import *


bound = 10


alterabstractsim(bound)
